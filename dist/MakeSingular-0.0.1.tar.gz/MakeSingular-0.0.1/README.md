# MakeSingular

Convert Plural To Singular

## Instruction

1. Install:

```
pip install MakeSingular
```

2. Convert Plural word to Singular

```python
from MakeSingular import PluralToSingular
```

# Call PluralToSingular

```
PluralToSingular.convert('apples')
```